# Nyatike Girls Education & Empowerment Initiative — Website Starter

This is a responsive Flask website starter with public pages and a working account login system.

## Included
- Home, About, Programs and Contact pages
- The two school activity photographs supplied by the user
- Mission, vision and tagline draft
- Login and logout
- One-time first administrator setup
- Password hashing (Werkzeug)
- Admin dashboard to create and delete user accounts
- Roles: admin, staff, volunteer
- SQLite database stored under `instance/ngo.db`

## Run locally
1. Install Python 3.10 or newer.
2. Extract the ZIP.
3. Open a terminal in this folder.
4. Create a virtual environment (recommended):
   - Windows: `py -m venv .venv` then `.venv\\Scripts\\activate`
   - macOS/Linux: `python3 -m venv .venv` then `source .venv/bin/activate`
5. Install dependencies: `pip install -r requirements.txt`
6. Set a strong secret key before running:
   - Windows PowerShell: `$env:SECRET_KEY="replace-with-a-long-random-secret"`
   - macOS/Linux: `export SECRET_KEY="replace-with-a-long-random-secret"`
7. Start: `python app.py`
8. Visit `http://127.0.0.1:5000/setup-admin` and create the first admin login.
9. Log in at `http://127.0.0.1:5000/login`.

## Important before public launch
- This is a starter project, not yet hosted on the internet.
- Set a strong, private `SECRET_KEY`; do not use the placeholder in production.
- Deploy behind HTTPS. Use a production WSGI server, not Flask's development server.
- Set secure cookie options and add CSRF protection, rate limiting, password reset and email verification before real-world use.
- Configure reliable backups and a privacy notice.
- Verify the NGO's official registered name and organisational details.
- The contact form currently prepares an email draft; it does not send or store messages.
- No donation/payment processing is configured.
- Do not upload children's sensitive information until suitable consent, privacy, safeguarding and access controls are in place.

## Current draft NGO wording
Working name: Nyatike Girls Education & Empowerment Initiative (NGEEI)
Mission: To empower girls in Nyatike North Sub-County to remain in school, overcome barriers to education and achieve their full potential through mentorship, educational support, advocacy and community engagement.
Vision: A community where every girl in Nyatike North Sub-County has an equal opportunity to remain in school, complete her education and build a bright and independent future.
Tagline: Keeping Girls in School, Building Brighter Futures.

Change the working name if your NGO has an official registered name.

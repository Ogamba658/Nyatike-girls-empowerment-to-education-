
import os, sqlite3
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash, g
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__, instance_relative_config=True)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "CHANGE-THIS-TO-A-LONG-RANDOM-SECRET-BEFORE-DEPLOYING")
app.config["DATABASE"] = os.path.join(app.instance_path, "ngo.db")
os.makedirs(app.instance_path, exist_ok=True)

def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(app.config["DATABASE"])
        g.db.row_factory = sqlite3.Row
    return g.db

@app.teardown_appcontext
def close_db(error=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()

def init_db():
    db = get_db()
    db.execute("""CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        full_name TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'staff',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )""")
    db.commit()

with app.app_context():
    init_db()

def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("user_id"):
            flash("Please log in to access the dashboard.", "info")
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped

def admin_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("user_id"):
            return redirect(url_for("login"))
        if session.get("role") != "admin":
            flash("Administrator access is required for that page.", "error")
            return redirect(url_for("dashboard"))
        return view(*args, **kwargs)
    return wrapped

@app.context_processor
def inject_user():
    return {"current_user": session.get("full_name"), "current_role": session.get("role")}

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/about")
def about():
    return render_template("about.html")

@app.route("/programs")
def programs():
    return render_template("programs.html")

@app.route("/contact", methods=["GET", "POST"])
def contact():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip()
        message = request.form.get("message", "").strip()
        if not name or not email or not message:
            flash("Please complete all fields.", "error")
        else:
            # This starter form opens an email draft; it does not store or send messages.
            mailto = f"mailto:ogambaDouglas746@yahoo.com?subject=Website%20enquiry%20from%20{name.replace(' ', '%20')}&body={message.replace(' ', '%20')}"
            flash("Your email app can be opened using the email link below. This demo form does not send messages directly.", "info")
            return render_template("contact.html", mailto=mailto, submitted=True)
    return render_template("contact.html", mailto=None, submitted=False)

@app.route("/setup-admin", methods=["GET", "POST"])
def setup_admin():
    db = get_db()
    count = db.execute("SELECT COUNT(*) AS n FROM users").fetchone()["n"]
    if count:
        flash("Administrator setup is already complete. Please log in.", "info")
        return redirect(url_for("login"))
    if request.method == "POST":
        full_name = request.form.get("full_name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        confirm = request.form.get("confirm", "")
        if not full_name or not email or len(password) < 12 or password != confirm:
            flash("Enter your name and email, use a password of at least 12 characters, and make both passwords match.", "error")
        else:
            db.execute("INSERT INTO users (full_name, email, password_hash, role) VALUES (?, ?, ?, 'admin')",
                       (full_name, email, generate_password_hash(password)))
            db.commit()
            flash("Administrator account created. Please log in.", "success")
            return redirect(url_for("login"))
    return render_template("setup_admin.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if session.get("user_id"):
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        user = get_db().execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session["user_id"] = user["id"]
            session["full_name"] = user["full_name"]
            session["role"] = user["role"]
            return redirect(url_for("dashboard"))
        flash("Email or password is incorrect.", "error")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "success")
    return redirect(url_for("home"))

@app.route("/dashboard")
@login_required
def dashboard():
    users = []
    if session.get("role") == "admin":
        users = get_db().execute("SELECT id, full_name, email, role, created_at FROM users ORDER BY id").fetchall()
    return render_template("dashboard.html", users=users)

@app.route("/admin/users", methods=["POST"])
@admin_required
def create_user():
    full_name = request.form.get("full_name", "").strip()
    email = request.form.get("email", "").strip().lower()
    password = request.form.get("password", "")
    role = request.form.get("role", "staff")
    if role not in ("staff", "volunteer", "admin"):
        role = "staff"
    if not full_name or not email or len(password) < 12:
        flash("Enter a name, email and password of at least 12 characters.", "error")
    else:
        try:
            get_db().execute("INSERT INTO users (full_name, email, password_hash, role) VALUES (?, ?, ?, ?)",
                             (full_name, email, generate_password_hash(password), role))
            get_db().commit()
            flash(f"Account created for {full_name}.", "success")
        except sqlite3.IntegrityError:
            flash("That email address already has an account.", "error")
    return redirect(url_for("dashboard"))

@app.route("/admin/users/<int:user_id>/delete", methods=["POST"])
@admin_required
def delete_user(user_id):
    if user_id == session.get("user_id"):
        flash("You cannot delete your own administrator account while logged in.", "error")
    else:
        get_db().execute("DELETE FROM users WHERE id = ?", (user_id,))
        get_db().commit()
        flash("Account deleted.", "success")
    return redirect(url_for("dashboard"))

if __name__ == "__main__":
    app.run(debug=True)
